#ifndef TRANSACTIONP_H
#define TRANSACTIONP_H

#include <QDialog>
#include <QtSql>
#include<QDebug>
#include<QFileInfo>
#include "stock.h"

namespace Ui {
class Transactionp;
}

class Transactionp : public QDialog
{
    Q_OBJECT

public:
    explicit Transactionp(QWidget *parent = 0);
    ~Transactionp();

private slots:
    void on_pushButton_clicked();

   // void on_trans_tab_activated(const QModelIndex &index);

private:
    Ui::Transactionp *ui;
};

#endif // TRANSACTIONP_H
