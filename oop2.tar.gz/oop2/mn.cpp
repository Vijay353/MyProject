#include "mn.h"
#include "ui_mn.h"

mn::mn(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::mn)
{
    ui->setupUi(this);
}

mn::~mn()
{
    delete ui;
}
