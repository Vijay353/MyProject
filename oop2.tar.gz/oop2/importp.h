#ifndef IMPORTP_H
#define IMPORTP_H

#include <QDialog>
#include <QtSql>
#include<QDebug>
#include<QFileInfo>
#include "stock.h"

namespace Ui {
class Importp;
}

class Importp : public QDialog
{
    Q_OBJECT

public:
    explicit Importp(QWidget *parent = 0);
    ~Importp();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Importp *ui;
};

#endif // IMPORTP_H
