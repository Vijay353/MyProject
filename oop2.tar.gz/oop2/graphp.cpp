#include "graphp.h"
#include "ui_graphp.h"
#include <QMessageBox>
#include <QtCharts>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>

QT_CHARTS_USE_NAMESPACE


using namespace QtCharts;


Graphp::Graphp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Graphp)
{
    ui->setupUi(this);
}

Graphp::~Graphp()
{
    delete ui;
}

void Graphp::on_pushButton_clicked()
{

    Graphp b;

    stock conn;
    if(!conn.connOpen()){

        qDebug() <<"Failed to open";
        return;

    }
    QSqlQuery qry;
    qry.prepare("select * from info6 ");
    if(qry.exec()) {

        int count=0;
        while(qry.next()){
        count++;

                     }

        ui->label11->setText("conneceted..");
        int i;

        QSqlQuery qry;
        qry.prepare("select * from info6 ");
        qry.exec();
         QBarSeries *series = new QBarSeries();
        for(i=0;i<count;i++)
          {
               qry.next();
               QString pname1=QString("%1").arg(qry.value(1).toString());
               QString pid1=QString("%1").arg(qry.value(0).toString());
              QSqlQuery tt,tte;
              tt.prepare("select qty,fqty from info8 where fqty>qty  and pid like '"+pid1+"'");
              tt.exec();
              tte.prepare("select qty,fqty from info8 where fqty < qty  and pid like '"+pid1+"'");
              tte.exec();
              int finsum=0,finsum1=0;
              while(tt.next())
              {

                   int inal=tt.value(0).toInt();
                   int fnal=tt.value(1).toInt();
                   finsum=finsum+fnal-inal;
              }
              while(tte.next())
              {

                   int inal=tte.value(0).toInt();
                   int fnal=tte.value(1).toInt();
                   finsum1=finsum1+inal-fnal;
              }

              QString pd1=QString("%1").arg(finsum1);
              QBarSet *trr =new QBarSet(pname1);
              *trr <<finsum <<finsum1;
              series->append(trr);
         }
         conn.connClose();
         QChart *chart = new QChart();
         chart->addSeries(series);
        chart->setTitle("Simple barchart example");
             chart->setAnimationOptions(QChart::SeriesAnimations);

             QStringList categories;
                   categories << "IMPORT QUANTITY"<<"EXPORT QUANTITY";
                   QBarCategoryAxis *axis = new QBarCategoryAxis();
                   axis->append(categories);
                   chart->createDefaultAxes();
                   chart->setAxisX(axis, series);

                   chart->legend()->setVisible(true);
                         chart->legend()->setAlignment(Qt::AlignBottom);

                         QChartView *chartView = new QChartView(chart);
                         chartView->setRenderHint(QPainter::Antialiasing);

                       QMainWindow window;
                               window.setCentralWidget(chartView);
                               window.resize(420, 300);
                              window.show();

        b.exec();


       }


}
