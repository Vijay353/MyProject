#include "importp.h"
#include "ui_importp.h"

#include <QMessageBox>
Importp::Importp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Importp)
{
    ui->setupUi(this);
}

Importp::~Importp()
{
    delete ui;
}

void Importp::on_pushButton_clicked()
{
    stock conn;
    QString pid;
    pid = ui->pid_im->text();

    if(!conn.connOpen()){

        qDebug() <<"Failed to open";
        return;

    }
    conn.connOpen();
    QSqlQuery qry;
    qry.prepare("select * from info6 where pid = '"+pid+"'");
    if(qry.exec()) {

        int count=0;
        while(qry.next()){
        count++;

    }
        if(count==1){

         ui->label_3->setText("product id is found");


           conn.connClose();

        }
        if(count>1){

            ui->label_3->setText("product id  are duplicates");
        }
        if(count<1){

            ui->label_3->setText("product id is not  found");
        }


       }
}

void Importp::on_pushButton_2_clicked()
{

    stock conn;
    QString pid,vendor;
    int qty;
    pid = ui->pid_im->text();
    qty = ui->qty_im->text().toInt();
    vendor = ui->vendor_im->text();

    if(!conn.connOpen()){

        qDebug() <<"Failed to open";
        return;

    }

   conn.connOpen();
    QSqlQuery qry,tqry,sqry;
    int tqty;
    qry.prepare("select * from info6 where pid='"+pid+"'");
    if(qry.exec()) {
        qry.next();
        tqty=qry.value(2).toInt();
         QString pname=QString("%1").arg(qry.value(1).toString());
         QString price=QString("%1").arg(qry.value(3).toString());
         QString qty1=QString("%1").arg(tqty);
         tqty=tqty+qty;
         QString status = QString("Found %1 item(s):").arg(tqty);
         QMessageBox::information(this, tr("Info"), status);
         QString status1 = QString("%1").arg(tqty);
          tqry.prepare("update info6 set qty='"+status1+"' where pid='"+pid+"'");
          tqry.exec();
          sqry.prepare("insert into info8 (customer,pid,pname,qty,fqty,price,date) values ('"+vendor+"','"+pid+"','"+pname+"','"+qty1+"','"+status1+"','"+price+"',CURRENT_TIMESTAMP)");
          sqry.exec();
          conn.connClose();

        }
    else {

        QMessageBox::critical(this,tr("error::"),qry.lastError().text());
    }

}
