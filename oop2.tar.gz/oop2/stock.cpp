#include "stock.h"
#include "ui_stock.h"
#include <QMessageBox>

stock::stock(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::stock)
{
    ui->setupUi(this);

    QPixmap pix("/home/vijay/image1.png");
    ui->label_pic->setPixmap(pix);




    if(!connOpen())
        ui->label_3->setText("error not opened!!!");
    else
        ui->label_3->setText("connected..");


}

stock::~stock()
{
    delete ui;
}

void stock::on_pushButton_clicked()
{
    QString username,password;
    username = ui->lineEdit_username->text();
    password = ui->lineEdit_password->text();


    if(!connOpen()){

        qDebug() <<"Failed to open";
        return;

    }
    connOpen();
    QSqlQuery qry;
    qry.prepare("select * from ino3 where username = '"+username+"'and password= '" +password+"'");

    if(qry.exec()) {

        int count=0;
        while(qry.next()){
        count++;

    }
        if(count==1){

            ui->label_4->setText("username and password are correct");
            connClose();
            this->hide();
            Homepage homepage;
            homepage.setModal(true);
            homepage.exec();
        }
        if(count>1){

            ui->label_4->setText("username and password are duplicates");
        }
        if(count<1){
         QMessageBox::critical(this,tr("Enter"),tr("invalid inputs:"));
        }

}
}
