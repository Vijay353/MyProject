#ifndef GRAPHP_H
#define GRAPHP_H

#include <QDialog>
#include <QtSql>
#include<QDebug>
#include<QFileInfo>
#include "stock.h"
#include <QtCharts>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>

namespace Ui {
class Graphp;
}

class Graphp : public QDialog
{
    Q_OBJECT

public:
    explicit Graphp(QWidget *parent = 0);
    ~Graphp();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Graphp *ui;
};

#endif // GRAPHP_H
