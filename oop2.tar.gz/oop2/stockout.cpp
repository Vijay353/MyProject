#include "stockout.h"
#include "ui_stockout.h"
#include <QMessageBox>

Stockout::Stockout(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Stockout)
{
    ui->setupUi(this);
}

Stockout::~Stockout()
{
    delete ui;
}

void Stockout::on_pushButton_clicked()
{
    stock conn;

    QSqlQueryModel *modal = new QSqlQueryModel();

    conn.connOpen();

    QSqlQuery *qry = new QSqlQuery(conn.mydb);

    qry->prepare("select pid,pname,qty,min from info6 where qty < min ");

    qry->exec();
    modal->setQuery(* qry);
    ui->stock_out->setModel(modal);

    conn.connClose();
    qDebug() << (modal->rowCount());


}
