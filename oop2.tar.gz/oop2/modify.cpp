#include "modify.h"
#include "ui_modify.h"
#include "stock.h"
#include <QMessageBox>
#include"iostream"

Modify::Modify(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Modify)
{
    ui->setupUi(this);
}

Modify::~Modify()
{
    delete ui;
}


void Modify::on_pushButton_clicked()
{
    stock conn;
    QString pid;
    pid = ui->pid_in->text();

    if(!conn.connOpen()){

        qDebug() <<"Failed to open";
        return;

    }
    conn.connOpen();
    QSqlQuery qry;
    qry.prepare("select * from info6 where pid = '"+pid+"'");
    if(qry.exec()) {

        int count=0;
        while(qry.next()){
        count++;

    }
        if(count==1){

         ui->label_5->setText("product id is found"); 
          qry.first();
           QString pname=QString("%1").arg(qry.value(1).toString());
            QString qty=QString("%1").arg(qry.value(2).toString());
             QString price=QString("%1").arg(qry.value(3).toString());
             QString min=QString("%1").arg(qry.value(4).toString());
             QString max=QString("%1").arg(qry.value(5).toString());
           ui->pname_in->setText(pname);
             ui->qty_in->setText(qty);
             ui->price_in->setText(price);
           ui->min_in->setText(min);

           ui->max_in->setText(max);

            conn.connClose();

        }
        if(count>1){

            ui->label_5->setText("product id  are duplicates");
        }
        if(count<1){

            ui->label_5->setText("product id is not  found");
        }


       }


}

void Modify::on_pushButton_2_clicked()
{


    stock conn;
    QString pid,pname,qty,price,min,max;
    pid = ui->pid_in->text();
    pname = ui->pname_in->text();
    qty = ui->qty_in->text();
    price = ui->price_in->text();
    min = ui->min_in->text();
    max = ui->max_in->text();
    if(!conn.connOpen()){

        qDebug() <<"Failed to open";
        return;

    }

   conn.connOpen();
    QSqlQuery qry;
    qry.prepare("update info6 set pname='"+pname+"',qty='"+qty+"',price='"+price+"',min='"+min+"',max='"+max+"' where pid='"+pid+"'");

    if(qry.exec()) {

    QMessageBox::critical(this,tr("Edit"),tr("Updated"));
    conn.connClose();

        }
    else {

        QMessageBox::critical(this,tr("error::"),qry.lastError().text());
    }

}
