#ifndef VIEWALL_H
#define VIEWALL_H

#include <QDialog>
#include <QtSql>
#include<QDebug>
#include<QFileInfo>
#include "stock.h"

namespace Ui {
class Viewall;
}

class Viewall : public QDialog
{
    Q_OBJECT

public:
    explicit Viewall(QWidget *parent = 0);
    ~Viewall();

private slots:
    void on_table_all_clicked();

private:
    Ui::Viewall *ui;
};

#endif // VIEWALL_H
