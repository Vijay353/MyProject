#include "add.h"
#include "ui_add.h"
#include "stock.h"
#include <QMessageBox>

Add::Add(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Add)
{
    ui->setupUi(this);
    stock conn;
}

Add::~Add()
{
    delete ui;
}

void Add::on_pushButton_clicked()
{
    stock conn;
    QString pid,pname,qty,price,min,max;
    pid = ui->pid_in->text();
    pname = ui->pname_in->text();
    qty = ui->qty_in->text();
    price = ui->price_in->text();
    min=ui->min_ad->text();
    max=ui->max_ad->text();

    if(!conn.connOpen()){

        qDebug() <<"Failed to open";
        return;

    }
   conn.connOpen();
    QSqlQuery qry;
    qry.prepare("insert into info6 (pid,pname,qty,price,min,max) values ('"+pid+"','"+pname+"','"+qty+"','"+price+"','"+min+"','"+max+"')");

    if(qry.exec()) {

    QMessageBox::critical(this,tr("Save"),tr("Saved"));
    conn.connClose();

        }
    else {

        QMessageBox::critical(this,tr("error::"),qry.lastError().text());
    }
}
