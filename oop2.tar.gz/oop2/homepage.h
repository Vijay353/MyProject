#ifndef HOMEPAGE_H
#define HOMEPAGE_H

#include <QDialog>
#include <QtSql>
#include<QDebug>
#include<QFileInfo>
#include "stock.h"
#include "add.h"
#include "modify.h"
#include "viewall.h"
#include "stockout.h"
#include "exportp.h"
#include "importp.h"
#include "graphp.h"
#include "transactionp.h"


namespace Ui {
class Homepage;
}

class Homepage : public QDialog
{
    Q_OBJECT
public:
    QSqlDatabase mydb;
    void connClose(){
        mydb.close();
        mydb.removeDatabase(QSqlDatabase::defaultConnection);

    }
    bool connOpen(){


        mydb = QSqlDatabase::addDatabase("QSQLITE");
        mydb.setDatabaseName("/home/vijay/project/stockm1.db");

        if(!mydb.open()) {
            qDebug()<<("error not opened!!!");
            return false;
        }
        else {
            qDebug()<<("connected..");
            return true;
        }

    }

public:
    explicit Homepage(QWidget *parent = 0);
    ~Homepage();

private slots:
    void on_pushButton_7_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_2_clicked();


    //void on_pushButton_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_clicked();

private:
    Ui::Homepage *ui;
};

#endif // HOMEPAGE_H
