#ifndef STOCK_H
#define STOCK_H

#include <QDialog>
#include <QMainWindow>
#include <QtSql>
#include<QDebug>
#include<QFileInfo>
#include "homepage.h"

namespace Ui {
class stock;
}

class stock : public QMainWindow
{
    Q_OBJECT

public:
    QSqlDatabase mydb;
    void connClose(){
        mydb.close();
        mydb.removeDatabase(QSqlDatabase::defaultConnection);

    }
    bool connOpen(){


        mydb = QSqlDatabase::addDatabase("QSQLITE");
        mydb.setDatabaseName("/home/vijay/project/stockm1.db");

        if(!mydb.open()) {
            qDebug()<<("error not opened!!!");
            return false;
        }
        else {
            qDebug()<<("connected..");
            return true;
        }

    }


public:
    explicit stock(QWidget *parent = 0);
    ~stock();

private slots:
    void on_pushButton_clicked();

private:
    Ui::stock *ui;

};

#endif // STOCK_H
