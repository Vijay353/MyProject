#include "viewall.h"
#include "ui_viewall.h"
#include "stock.h"
#include <QMessageBox>

Viewall::Viewall(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Viewall)
{
    ui->setupUi(this);
}

Viewall::~Viewall()
{
    delete ui;
}

void Viewall::on_table_all_clicked()
{

    stock conn;

    QSqlQueryModel *modal = new QSqlQueryModel();

    conn.connOpen();

    QSqlQuery *qry = new QSqlQuery(conn.mydb);
    qry->prepare("select * from info6");

    qry->exec();
    modal->setQuery(* qry);
    ui-> table_tb->setModel(modal);

    conn.connClose();
    qDebug() << (modal->rowCount());


}
