#include "homepage.h"
#include "ui_homepage.h"
#include "stock.h"


Homepage::Homepage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Homepage)
{
    ui->setupUi(this);
   stock conn;

    if(!connOpen())
        ui->label_sec->setText("error not opened!!!");
    else
        ui->label_sec->setText("connected..");
}

Homepage::~Homepage()
{
    delete ui;
}

void Homepage::on_pushButton_7_clicked()
{
    Add add;
    add.setModal(true);
    add.exec();

}

void Homepage::on_pushButton_6_clicked()
{
    Modify modify;
    modify.setModal(true);
    modify.exec();
}

void Homepage::on_pushButton_4_clicked()
{
    Viewall viewall;
    viewall.setModal(true);
    viewall.exec();
}

void Homepage::on_pushButton_3_clicked()
{
    Stockout stockout;
    stockout.setModal(true);
    stockout.exec();
}


void Homepage::on_pushButton_2_clicked()
{
    Exportp exportp;
    exportp.setModal(true);
    exportp.exec();
}

void Homepage::on_pushButton_9_clicked()
{
    Importp importp;
    importp.setModal(true);
    importp.exec();

}

void Homepage::on_pushButton_5_clicked()
{

   connClose();
   this->hide();
}

void Homepage::on_pushButton_8_clicked()
{
    Graphp graphp;
    graphp.setModal(true);
    graphp.exec();


}

void Homepage::on_pushButton_clicked()
{
    Transactionp transactionp;
    transactionp.setModal(true);
    transactionp.exec();
}
