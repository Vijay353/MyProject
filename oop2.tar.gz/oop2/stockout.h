#ifndef STOCKOUT_H
#define STOCKOUT_H

#include <QDialog>
#include <QtSql>
#include<QDebug>
#include<QFileInfo>
#include "stock.h"

namespace Ui {
class Stockout;
}

class Stockout : public QDialog
{
    Q_OBJECT

public:
    explicit Stockout(QWidget *parent = 0);
    ~Stockout();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Stockout *ui;
};

#endif // STOCKOUT_H
