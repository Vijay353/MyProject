#ifndef EXPORTP_H
#define EXPORTP_H

#include <QDialog>
#include <QtSql>
#include<QDebug>
#include<QFileInfo>
#include "stock.h"

namespace Ui {
class Exportp;
}

class Exportp : public QDialog
{
    Q_OBJECT

public:
    explicit Exportp(QWidget *parent = 0);
    ~Exportp();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    //void on_pushButton_3_clicked();

private:
    Ui::Exportp *ui;
};

#endif // EXPORTP_H
