#include "transactionp.h"
#include "ui_transactionp.h"
#include <QMessageBox>

Transactionp::Transactionp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Transactionp)
{
    ui->setupUi(this);
}

Transactionp::~Transactionp()
{
    delete ui;
}

void Transactionp::on_pushButton_clicked()
{
    stock conn;
    QString date;
  date = ui->date_in->text();

    if(!conn.connOpen()){

        qDebug() <<"Failed to open";
        return;

    }

    QString status = QString("%1").arg(date);
     QString status1 = QString("%1").arg("");
    status1.append('2');
    status1.append('0');
    status1.append(status[6]);
    status1.append(status[7]);
    status1.append('-');
    status1.append(status[3]);
    status1.append(status[4]);
    status1.append('-');
    status1.append(status[0]);
    status1.append(status[1]);


         QMessageBox::information(this,tr("date"),status1);
         conn.connOpen();
         ui->label->setText("found");
         QSqlQueryModel *modal = new QSqlQueryModel();

         conn.connOpen();

         QSqlQuery *qry = new QSqlQuery(conn.mydb);
         qry->prepare("select * from info8 where date like '"+status1+"%' ");

         qry->exec();
         modal->setQuery(* qry);
         ui-> trans_tab->setModel(modal);

         conn.connClose();
         qDebug() << (modal->rowCount());
         conn.connClose();

    }


