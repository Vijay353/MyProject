#ifndef MN_H
#define MN_H

#include <QDialog>

namespace Ui {
class mn;
}

class mn : public QDialog
{
    Q_OBJECT

public:
    explicit mn(QWidget *parent = 0);
    ~mn();

private:
    Ui::mn *ui;
};

#endif // MN_H
